-- Setup & load table for bulk bookstore file

BEGIN;

-- drop table
drop table if exists mobile_data;

-- create table to match mobile_data.csv

-- Model,Display,Camera,RAM,Battery,Processor
create table mobile_data (
Model text primary key,
Display decimal (10,1) not null,
Camera int,
RAM text,
Battery int,
Processor text
);

-- client-side copy
\copy mobile_data from '/home/murthy/assignment1/DA_Assignment3/mobile_data.csv' with csv header;

COMMIT;

