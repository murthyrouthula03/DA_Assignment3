BEGIN;

-- table-info
\d mobile_data

-- drop tables gadget_table, gadget_ram, gadget_proc if exists
drop table if exists gadget_ram;
drop table if exists gadget_proc;
drop table if exists gadget_table;

-- creating table gadget_table from mobile_data
CREATE TABLE gadget_table AS SELECT model, display, camera, battery from mobile_data;

-- making model in gadget table as primary key
ALTER TABLE gadget_table ADD PRIMARY KEY (model);

-- creating table gadget_ram from mobile_data and attaining 1NF
CREATE TABLE gadget_ram AS SELECT model, unnest(string_to_array(ram,';')) from mobile_data;

-- removing duplicate rows if exists in gadget_ram
DELETE  FROM gadget_ram a USING gadget_ram b WHERE a.ctid < b.ctid AND a.model = b.model AND a.unnest = b.unnest;

-- changing column name 'unnest' of gadget_ram to 'ram', changing datatype to float and making model as foreign key referencing primary key of gadget_table
ALTER TABLE gadget_ram RENAME COLUMN unnest TO ram;
ALTER TABLE gadget_ram  ALTER COLUMN ram TYPE FLOAT USING (CASE WHEN ram = '' THEN 0.0 ELSE ram::float END);;
ALTER TABLE gadget_ram ADD FOREIGN KEY (model) REFERENCES gadget_table(model) ON UPDATE CASCADE ON DELETE CASCADE;

-- creating table gadget_proc from mobile_data and attaining 1NF
CREATE TABLE gadget_proc AS SELECT model, unnest(string_to_array(processor,';')) from mobile_data;

-- removing duplicate rows if exists in gadget_proc
DELETE  FROM gadget_proc a USING gadget_proc b WHERE a.ctid < b.ctid AND a.model = b.model AND a.unnest = b.unnest;

-- changing column name 'unnest' of gadget_proc to 'processor' and making model as foreign key referencing primary key of gadget_table
ALTER TABLE gadget_proc RENAME COLUMN unnest TO processor;
ALTER TABLE gadget_proc ADD FOREIGN KEY (model) REFERENCES gadget_table(model)  ON UPDATE CASCADE ON DELETE CASCADE;

-- checking info of all tables

\d gadget_table
\d gadget_ram
\d gadget_proc

-- Selecting tables gadget_table, gadget_ram, gadget_proc
select * from gadget_table;
select * from gadget_ram;
select * from gadget_proc;

-- selecting the gadgets whose ram more than 6gb using joins
SELECT gadget_table.model, gadget_table.camera, gadget_ram.ram, gadget_table.battery, gadget_table.display FROM gadget_table INNER JOIN gadget_ram ON gadget_table.model = gadget_ram.model where gadget_ram.ram > 4 AND gadget_ram.ram < 8;

-- mapping the gadgets with ram using left join
SELECT gadget_table.model, gadget_table.camera, gadget_table.battery, gadget_table.display, gadget_proc.processor FROM gadget_table LEFT JOIN gadget_proc ON gadget_table.model = gadget_proc.model;

-- getting the models of gadgets_table in the order of Descending display size, Descending camera, Ascending battery
SELECT * FROM gadget_table ORDER BY display DESC, camera DESC, battery ASC;

-- getting the models of gadgets with ram greater than 5gb with Ascending display size, Ascending camera pixels and Descending Battery
SELECT gadget_table.model, gadget_table.display, gadget_table.camera, gadget_table.battery, gadget_ram.ram FROM gadget_table INNER JOIN gadget_ram ON gadget_table.model = gadget_ram.model where gadget_ram.ram > 5 ORDER BY gadget_table.display ASC, gadget_table.camera ASC, gadget_table.battery DESC;

-- getting average battery giving to every RAM size
SELECT A.ram, AVG(A.battery) as avg_battery FROM (SELECT * FROM gadget_table INNER JOIN gadget_ram ON gadget_table.model = gadget_ram.model) as A GROUP BY (A.ram) ORDER BY A.ram ASC;

-- getting maximum and minimum cameras given based on RAM size
SELECT display, MAX(camera) as max_camera, MIN(camera) as min_camera FROM gadget_table GROUP BY (display) ORDER BY display ASC;

-- getting maximum and minimum battery given based on cameras
SELECT camera, MAX(battery) as max_battery, MIN(battery) as min_battery FROM gadget_table where camera !=0 GROUP BY (camera) ORDER BY camera ASC;

COMMIT;
