BEGIN;

-- table-info
\d mobile_data

-- checking data in the table
select * from mobile_data;

-- checking number of rows in the table
select count(*) from mobile_data;

COMMIT;
