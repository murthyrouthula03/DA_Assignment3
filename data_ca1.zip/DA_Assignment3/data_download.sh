: "Data was scraped from gsmarena.com using Python's Selenium webdriver and Beautiful Soup and scp from local system to  this server.
./mobile_data.csv is initial unnormalized file  in the folder."
