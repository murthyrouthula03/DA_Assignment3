Info about Data:
---------------
1. The data is scraped from gsmarena.com through using Python's Selenium webdriver and Beautiful Soup.
2. The data contains info of Samsung mobiles their Models, Display size, RAM, Camera pixels, Processor.
3. RAM and Processor contains different versions released for particular model separated by ';'.
4. After Scraping, data is copied from local server to this server as mobile_data.csv.

Working with Data:
-----------------

-> Loading the data into mobile_data table which has 'Model' column as primary key.
-> As the Initial data is Unnormalised, making the data Normalised in table.
-> Creation of Normalised tables using subselects.
-> Selecting the Normalised data based on conditions.
-> Applying Joins on the Normalised data.
-> Selecting data based on ordering columns Ascending or descending.
-> Using Group by and executing aggregate functions like AVG, MAX, MIN.

outputs shown:
-------------

-> selecting the gadgets whose ram more than 6gb using joins.
-> mapping the gadgets with ram using left join.
-> getting the models of gadgets_table in the order of Descending display size, Descending camera, Ascending battery.
-> getting the models of gadgets with ram greater than 5gb with Ascending display size, Ascending camera pixels and Descending Battery.
-> getting average battery giving to every RAM size
-> getting maximum and minimum cameras given based on RAM size
-> getting maximum and minimum battery given based on cameras

Normalisation steps(3 NF):
-------------------------

-> Main table contains columns Gadget models(unique and Not null), Display size, RAM(2 or 3 values separated by ';'), Camera pixels, Processor(contains 1 or 2 values separated by ';').
-> According to the above main tables, we are dividing and arranging them in other tables to attain 3NF.
-> Taking Gadget model, Display size, Camera pixels into table 'gadget_table' with Gadget model as primary key.
-> Taking Gadget model, RAM into table 'gadget_ram' and to attain 1NF, we are melting rows by dividing RAM as ';' delimeter and removing dupicate rows.
-> To attain 2NF,  Gadget model in gadget_ram table is converting to foreign key referencing primary key of gadget_table.
-> Taking Gadget model, Processor in other table gadget_proc and Gadget model is converting to foreign key referencing primary key of gadget_table.
-> To attain 3NF, we are making sure that there is 1NF and 2NF implemented and there wont be any transitive functional dependency between columns as we referencing all the unique values of gadget_table with gadget_ram and gadget_proc tables.

ER Overview:
-----------

-> Samsung company has many Gadgets.
-> Gadgets has one or many versions of Gadget models.
-> Gadgets has one or many Processor versions.
-> Gadgets has one or many RAM versions.
-> Gadgets has zero or many Cameras.
-> Gadgets has one or many Display sizes.
-> Each Gadget model has only one Display size.
-> Each Gadget model has only one RAM version.
-> Each Gadget model has only one main Camera or no Camera.
-> Each Gadget model has only one Processor version.
